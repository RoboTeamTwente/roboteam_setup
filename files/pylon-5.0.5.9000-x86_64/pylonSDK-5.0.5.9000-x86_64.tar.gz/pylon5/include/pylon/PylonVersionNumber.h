// This file is generated automatically during PYLON build process
// DO NOT EDIT

#define PYLON_VERSION_MAJOR           5
#define PYLON_VERSION_MINOR           0
#define PYLON_VERSION_SUBMINOR        5
#define PYLON_VERSION_BUILD           9000
#define PYLON_VERSIONSTRING_MAJOR     "5"
#define PYLON_VERSIONSTRING_MINOR     "0"
#define PYLON_VERSIONSTRING_SUBMINOR  "5"
#define PYLON_VERSIONSTRING_BUILD     "9000"
#define PYLON_VERSIONSTRING_EXTENSION ""

// Windows only:
#define PYLON_VERSIONSTRING_COMMENT   "${build.timestamp}; ${env.COMPUTERNAME}"
