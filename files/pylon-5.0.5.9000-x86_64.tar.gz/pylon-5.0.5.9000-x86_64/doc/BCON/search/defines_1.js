var searchData=
[
  ['extern_5fc_5fbegin',['EXTERN_C_BEGIN',['../_bcon_adapter_defines_8h.html#a6774b472721b30450b3334dc4f718a72',1,'BconAdapterDefines.h']]],
  ['extern_5fc_5fend',['EXTERN_C_END',['../_bcon_adapter_defines_8h.html#ada1a24bb49d1a045f735dc027664ae57',1,'BconAdapterDefines.h']]]
];
