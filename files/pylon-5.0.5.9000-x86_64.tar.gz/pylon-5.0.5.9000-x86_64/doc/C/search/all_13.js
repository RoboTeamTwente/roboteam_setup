var searchData=
[
  ['vendorname',['VendorName',['../struct_pylon_device_info__t.html#a4760236e19364d74e4389552d1942f58',1,'PylonDeviceInfo_t']]]
];
