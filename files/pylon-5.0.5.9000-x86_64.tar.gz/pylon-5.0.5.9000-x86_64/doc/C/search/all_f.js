var searchData=
[
  ['ro',['RO',['../group__genapi.html#gga0722c4c9851710e9c198ec47d287b0c5a42e9aa764b9ee7ecf7e668462de6f96d',1,'GenApiCEnums.h']]],
  ['rw',['RW',['../group__genapi.html#gga0722c4c9851710e9c198ec47d287b0c5aec2497e0c8af01c04bec31ec0d1d7847',1,'GenApiCEnums.h']]]
];
