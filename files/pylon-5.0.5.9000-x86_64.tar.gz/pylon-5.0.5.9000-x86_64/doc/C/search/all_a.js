var searchData=
[
  ['modelname',['ModelName',['../struct_pylon_device_info__t.html#a166b322af3cf7b7b8c4a0e24871d0216',1,'PylonDeviceInfo_t']]]
];
