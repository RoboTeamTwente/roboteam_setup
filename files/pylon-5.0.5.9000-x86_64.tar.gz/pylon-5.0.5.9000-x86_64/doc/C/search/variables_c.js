var searchData=
[
  ['userdefinedname',['UserDefinedName',['../struct_pylon_device_info__t.html#a8f25436a743706920e1aecf0605c95f8',1,'PylonDeviceInfo_t']]]
];
